package com.nikhil.webscraping;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebscrapingApplication {

	public static void main(String[] args) {
		// https://stackoverflow.com/questions/tagged/python
		// https://stackoverflow.com/questions/tagged/python?tab=Newest
		String url = "https://stackoverflow.com/questions/tagged/python  ";
		Document doc;
		try {
			doc = Jsoup.connect(url).get();
			Elements elements = doc.select("div#questions");
			for (Element element : elements) {
				System.out.println(element.text());
				System.out.println(element.getElementsByTag("a").first().text());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
