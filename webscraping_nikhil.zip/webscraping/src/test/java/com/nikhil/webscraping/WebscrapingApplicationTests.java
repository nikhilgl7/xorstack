package com.nikhil.webscraping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebscrapingApplicationTests {

	@Test
	void contextLoads() {
	}

}
