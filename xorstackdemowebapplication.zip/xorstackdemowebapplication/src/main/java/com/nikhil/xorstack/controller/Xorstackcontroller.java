package com.nikhil.xorstack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nikhil.xorstack.entity.Employee;
import com.nikhil.xorstack.service.Xorstackservice;

@Controller
@RequestMapping("/employee")
public class Xorstackcontroller {

	@Autowired
	private Xorstackservice xorstackservice;
	
	@PostMapping(value = "/add")
	public String addEmployee(@ModelAttribute Employee employee, Model model) {
		System.out.println("in controller add method"); 
		Employee emp = xorstackservice.addEmployee(employee);
		System.out.println("Employee saved "+emp);
		model.addAttribute("employee", emp);   
		return "index";
	}
	
	@PostMapping(value = "/update")
	public String updateEmployee(@ModelAttribute Employee employee) {
		System.out.println("in controller update method"); 
		xorstackservice.updateEmployee(employee);
		 return "index";
	}
	
	@GetMapping(value = "/get")
	public String getEmployee(@RequestParam String id) {
		System.out.println("in controller select method"); 
		xorstackservice.getEmployee(Long.valueOf(id));
		 return "index";
	}
	
	@RequestMapping(value = "/delete")
	public String deleteEmployee(@RequestParam String id) {
		System.out.println("in controller delete method"); 
		xorstackservice.deleteEmployee(Long.valueOf(id));
		 return "index";
	}
}
