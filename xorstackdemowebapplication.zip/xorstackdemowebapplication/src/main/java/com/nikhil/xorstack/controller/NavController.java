package com.nikhil.xorstack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class NavController {
	@GetMapping("/add")
	public String addUser() {
		return "index";

	}

	@GetMapping("/update")
	public String updateUser() {
		return "update";
	}

	@GetMapping("/delete")
	public String deleteUser() {
		return "delete";
	}

	@GetMapping("/select")
	public String selectUser() {
		return "select";
	}
}
