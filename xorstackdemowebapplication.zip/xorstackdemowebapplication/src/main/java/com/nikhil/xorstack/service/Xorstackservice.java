package com.nikhil.xorstack.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nikhil.xorstack.entity.Employee;
import com.nikhil.xorstack.repo.XorstackRepository;

@Service
public class Xorstackservice {

	@Autowired
	private XorstackRepository xorstackRepository;
	
	public Employee addEmployee(Employee employee) {
		return xorstackRepository.save(employee);
	}
	@Transactional
	public void updateEmployee(Employee employee) {
		Optional<Employee> empl = xorstackRepository.findById(employee.getId());
		if(empl.isPresent()) {
			xorstackRepository.save(employee);
		} 
	}
	
	public Employee getEmployee(Long employeeId) {
		Optional<Employee> empl = xorstackRepository.findById(employeeId);
		return empl.get();
	}
	@Transactional
	public void deleteEmployee(Long employeeId) {
		Optional<Employee> empl = xorstackRepository.findById(employeeId);
		if(empl.isPresent()) {
			xorstackRepository.deleteById(employeeId);
		}
	}
}
