package com.nikhil.xorstack.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nikhil.xorstack.entity.Employee;

public interface XorstackRepository extends JpaRepository<Employee, Long>{

}
