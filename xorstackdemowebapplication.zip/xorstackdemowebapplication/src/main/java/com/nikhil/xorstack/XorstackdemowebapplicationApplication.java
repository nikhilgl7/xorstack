package com.nikhil.xorstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XorstackdemowebapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(XorstackdemowebapplicationApplication.class, args);
	}

}
