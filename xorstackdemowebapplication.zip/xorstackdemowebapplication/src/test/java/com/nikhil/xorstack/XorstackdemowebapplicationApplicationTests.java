package com.nikhil.xorstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XorstackdemowebapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
